Source Code is written with C++ in Visual Studio 2015 Community Edition.

It runs perfect on Windows 8 with OpenCV 3.1.0